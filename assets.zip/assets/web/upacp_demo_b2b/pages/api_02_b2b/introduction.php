<!-- <h3>内容标题 1</h3> -->
<p>联调集成前请仔细阅读：<a href="pages/api_02_b2b/readme.txt" target="_blank">readme.txt</a></p>
<p>接口规范(请求报文，同步应答，异步应答报文字段)参考：<a href="https://open.unionpay.com/ajweb/help/file" target="_blank">产品接口规范->《B2B支付产品接口规范》</a></p>
<p>应答码规范(同步应答，异步应答中respCode的值)参考：<a href="https://open.unionpay.com/ajweb/help/file" target="_blank">产品接口规范->《平台接入接口规范-第5部分-附录》</a></p>
<p>对账文件格式参考：<a href="https://open.unionpay.com/ajweb/help/file" target="_blank">产品接口规范->《全渠道平台接入接口规范 第3部分 文件接口》</a></p>
